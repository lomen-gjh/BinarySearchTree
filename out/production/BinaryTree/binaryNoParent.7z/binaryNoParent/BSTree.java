package binaryNoParent;

public class BSTree {
    Node root;
    BSTree(){
        root=null;
    }

    void insert(int d){
        if (root!=null)
            root.insert(d);
        else
            root=new Node(d);
    }

    Node delete(int v){
        if (root!=null){
            if (root.getData()==v){
                if (root.getLeft()!=null)
                {
                    Node maxP= root.findMaxParent();
                    Node replacement= maxP.getRight();
                    maxP.right=replacement.left;

                    replacement.left=root.left;
                    replacement.right=root.right;
                    root=replacement;
                    return replacement;
                }
                if (root.getRight()!=null)
                {
                    Node minP=root.findMinParent();
                    Node replacement = minP.getLeft();
                    minP.left=replacement.right;

                    replacement.left=root.left;
                    replacement.right=root.right;
                    root=replacement;
                    return replacement;
                }
                else
                {
                    Node deleted=root;
                    root=null;
                    return deleted;
                }


            }
            return root.delete(v);

        }

        return null;

    }

    public static void main(String args[]){
        BSTree tree=new BSTree();
        tree.insert(50);
        tree.insert(25);
        tree.insert(9);
        tree.insert(58);
        tree.insert(53);
        tree.insert(90);
        tree.insert(28);
        tree.root.inorder();
        System.out.println();
        tree.delete(58);
        tree.root.postorder();



    }
}
